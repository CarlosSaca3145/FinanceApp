import { 
  type User, 
  type InsertUser, 
  type Brand, 
  type InsertBrand,
  type ContentTemplate,
  type InsertContentTemplate,
  type FollowupTemplate,
  type InsertFollowupTemplate,
  type EmailLog,
  type InsertEmailLog,
  users,
  brands,
  contentTemplates,
  followupTemplates,
  emailLogs
} from "@shared/schema";
import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, desc, sql, isNotNull, ne } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Brands
  getBrands(): Promise<Brand[]>;
  getBrand(id: string): Promise<Brand | undefined>;
  createBrand(brand: InsertBrand): Promise<Brand>;
  updateBrand(id: string, brand: Partial<Brand>): Promise<Brand | undefined>;
  deleteBrand(id: string): Promise<boolean>;
  createManyBrands(brands: InsertBrand[]): Promise<Brand[]>;
  getUniqueNiches(): Promise<string[]>;

  // Content Templates
  getContentTemplates(): Promise<ContentTemplate[]>;
  getContentTemplateByNiche(nicho: string): Promise<ContentTemplate | undefined>;
  createContentTemplate(template: InsertContentTemplate): Promise<ContentTemplate>;
  updateContentTemplate(id: string, template: Partial<ContentTemplate>): Promise<ContentTemplate | undefined>;
  deleteContentTemplate(id: string): Promise<boolean>;
  upsertContentTemplateByNiche(nicho: string, template: Partial<InsertContentTemplate>): Promise<ContentTemplate>;

  // Followup Templates
  getFollowupTemplates(): Promise<FollowupTemplate[]>;
  getFollowupTemplate(id: string): Promise<FollowupTemplate | undefined>;
  createFollowupTemplate(template: InsertFollowupTemplate): Promise<FollowupTemplate>;
  updateFollowupTemplate(id: string, template: Partial<FollowupTemplate>): Promise<FollowupTemplate | undefined>;
  deleteFollowupTemplate(id: string): Promise<boolean>;

  // Email Logs
  getEmailLogs(): Promise<EmailLog[]>;
  createEmailLog(log: InsertEmailLog): Promise<EmailLog>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private brands: Map<string, Brand>;
  private contentTemplates: Map<string, ContentTemplate>;
  private followupTemplates: Map<string, FollowupTemplate>;
  private emailLogs: Map<string, EmailLog>;

  constructor() {
    this.users = new Map();
    this.brands = new Map();
    this.contentTemplates = new Map();
    this.followupTemplates = new Map();
    this.emailLogs = new Map();

    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample content templates
    const sampleTemplates = [
      {
        id: randomUUID(),
        nicho: "smartphones",
        contenido: "📱 Just tested the new iPhone 15 Pro - the camera quality is incredible! Check out these low-light shots...",
        idea: "Test the camera quality in different lighting conditions",
        videoLinks: ["https://www.youtube.com/shorts/example1"],
        videoTitles: ["iPhone 15 Pro Camera Test - Low Light Performance"],
        videoIdeas: null,
        videoViews: null,
        fullTemplate: null,
        originalIdea: null,
        proposedIdea: null,
        views: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: randomUUID(),
        nicho: "drones",
        contenido: "🚁 Amazing aerial footage from our latest drone test! This DJI Mini 4 Pro captured stunning 4K video at 200ft altitude. Perfect for travel content creators...",
        idea: "Showcase aerial photography capabilities for travel content",
        videoLinks: ["https://www.youtube.com/shorts/example2"],
        videoTitles: ["DJI Mini 4 Pro - 4K Aerial Photography Test"],
        videoIdeas: null,
        videoViews: null,
        fullTemplate: null,
        originalIdea: null,
        proposedIdea: null,
        views: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: randomUUID(),
        nicho: "microphones",
        contenido: "🎙️ Crystal clear audio test with the Blue Yeti X! Perfect for podcasting and streaming. Listen to this before/after comparison...",
        idea: "Test audio quality for podcasting and streaming",
        videoLinks: ["https://www.youtube.com/shorts/example3"],
        videoTitles: ["Blue Yeti X Microphone - Audio Quality Test"],
        videoIdeas: null,
        videoViews: null,
        fullTemplate: null,
        originalIdea: null,
        proposedIdea: null,
        views: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: randomUUID(),
        nicho: "robot vacuums",
        contenido: "🤖 Testing the latest Roomba j7+ - the obstacle avoidance is impressive! Watch how it navigates around pet toys and cables...",
        idea: "Demonstrate smart navigation and obstacle avoidance",
        videoLinks: ["https://www.youtube.com/shorts/example4"],
        videoTitles: ["Roomba j7+ Obstacle Avoidance Test"],
        videoIdeas: null,
        videoViews: null,
        fullTemplate: null,
        originalIdea: null,
        proposedIdea: null,
        views: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    sampleTemplates.forEach(template => {
      this.contentTemplates.set(template.id, template);
    });

    // Sample followup template
    const followupTemplate = {
      id: randomUUID(),
      name: "General Follow-up",
      template: "Hi {{contacto}},\n\nI wanted to follow up on my previous email regarding our collaboration opportunity. We're still very interested in working with your brand and showcasing your products to our engaged audience.\n\nWould you be available for a quick call this week to discuss the partnership?",
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.followupTemplates.set(followupTemplate.id, followupTemplate);
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Brands
  async getBrands(): Promise<Brand[]> {
    return Array.from(this.brands.values()).sort((a, b) => 
      a.marca.localeCompare(b.marca)
    );
  }

  async getBrand(id: string): Promise<Brand | undefined> {
    return this.brands.get(id);
  }

  async createBrand(insertBrand: InsertBrand): Promise<Brand> {
    const id = randomUUID();
    const brand: Brand = { 
      ...insertBrand, 
      id, 
      createdAt: new Date(),
      contacto: insertBrand.contacto ?? null,
      contactos: insertBrand.contactos ?? null,
      correos: insertBrand.correos ?? null,
      campania: insertBrand.campania ?? null,
      estado: insertBrand.estado ?? null,
      fechaEnvio: insertBrand.fechaEnvio ?? null,
      seguimientoModelo: insertBrand.seguimientoModelo ?? null,
      notes: insertBrand.notes ?? null
    };
    this.brands.set(id, brand);
    return brand;
  }

  async updateBrand(id: string, brandUpdate: Partial<Brand>): Promise<Brand | undefined> {
    const existing = this.brands.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...brandUpdate };
    this.brands.set(id, updated);
    return updated;
  }

  async deleteBrand(id: string): Promise<boolean> {
    return this.brands.delete(id);
  }

  async createManyBrands(insertBrands: InsertBrand[]): Promise<Brand[]> {
    const createdBrands: Brand[] = [];
    for (const insertBrand of insertBrands) {
      const brand = await this.createBrand(insertBrand);
      createdBrands.push(brand);
    }
    return createdBrands;
  }

  async getUniqueNiches(): Promise<string[]> {
    const allBrands = Array.from(this.brands.values());
    const niches = new Set<string>();
    
    allBrands.forEach(brand => {
      if (brand.nicho && brand.nicho.trim() !== '') {
        niches.add(brand.nicho);
      }
    });
    
    return Array.from(niches).sort();
  }

  // Content Templates
  async getContentTemplates(): Promise<ContentTemplate[]> {
    return Array.from(this.contentTemplates.values());
  }

  async getContentTemplateByNiche(nicho: string): Promise<ContentTemplate | undefined> {
    return Array.from(this.contentTemplates.values()).find(
      template => template.nicho.toLowerCase() === nicho.toLowerCase()
    );
  }

  async createContentTemplate(insertTemplate: InsertContentTemplate): Promise<ContentTemplate> {
    const id = randomUUID();
    const template: ContentTemplate = {
      ...insertTemplate,
      id,
      idea: insertTemplate.idea ?? null,
      videoLinks: insertTemplate.videoLinks ?? null,
      videoTitles: insertTemplate.videoTitles ?? null,
      videoIdeas: insertTemplate.videoIdeas ?? null,
      videoViews: insertTemplate.videoViews ?? null,
      fullTemplate: insertTemplate.fullTemplate ?? null,
      originalIdea: insertTemplate.originalIdea ?? null,
      proposedIdea: insertTemplate.proposedIdea ?? null,
      views: insertTemplate.views ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.contentTemplates.set(id, template);
    return template;
  }

  async updateContentTemplate(id: string, templateUpdate: Partial<ContentTemplate>): Promise<ContentTemplate | undefined> {
    const existing = this.contentTemplates.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...templateUpdate, updatedAt: new Date() };
    this.contentTemplates.set(id, updated);
    return updated;
  }

  async deleteContentTemplate(id: string): Promise<boolean> {
    return this.contentTemplates.delete(id);
  }

  async upsertContentTemplateByNiche(nicho: string, templateUpdate: Partial<InsertContentTemplate>): Promise<ContentTemplate> {
    const existing = await this.getContentTemplateByNiche(nicho);
    
    if (existing) {
      // Merge video links (dedupe)
      const mergedVideoLinks = existing.videoLinks || [];
      if (templateUpdate.videoLinks) {
        for (const link of templateUpdate.videoLinks) {
          if (!mergedVideoLinks.includes(link)) {
            mergedVideoLinks.push(link);
          }
        }
      }
      
      // Merge video ideas (maintain correspondence with links)
      const mergedVideoIdeas = existing.videoIdeas || [];
      if (templateUpdate.videoIdeas) {
        for (const idea of templateUpdate.videoIdeas) {
          mergedVideoIdeas.push(idea);
        }
      }
      
      // Merge video views (maintain correspondence with links)
      const mergedVideoViews = existing.videoViews || [];
      if (templateUpdate.videoViews) {
        for (const view of templateUpdate.videoViews) {
          mergedVideoViews.push(view);
        }
      }
      
      const updated = await this.updateContentTemplate(existing.id, {
        ...templateUpdate,
        videoLinks: mergedVideoLinks,
        videoIdeas: mergedVideoIdeas,
        videoViews: mergedVideoViews
      });
      return updated!;
    } else {
      return await this.createContentTemplate({
        nicho,
        contenido: templateUpdate.contenido || `Content for ${nicho}`,
        idea: templateUpdate.idea,
        videoLinks: templateUpdate.videoLinks
      });
    }
  }

  // Followup Templates
  async getFollowupTemplates(): Promise<FollowupTemplate[]> {
    return Array.from(this.followupTemplates.values());
  }

  async getFollowupTemplate(id: string): Promise<FollowupTemplate | undefined> {
    return this.followupTemplates.get(id);
  }

  async createFollowupTemplate(insertTemplate: InsertFollowupTemplate): Promise<FollowupTemplate> {
    const id = randomUUID();
    const template: FollowupTemplate = {
      ...insertTemplate,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.followupTemplates.set(id, template);
    return template;
  }

  async updateFollowupTemplate(id: string, templateUpdate: Partial<FollowupTemplate>): Promise<FollowupTemplate | undefined> {
    const existing = this.followupTemplates.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...templateUpdate, updatedAt: new Date() };
    this.followupTemplates.set(id, updated);
    return updated;
  }

  async deleteFollowupTemplate(id: string): Promise<boolean> {
    return this.followupTemplates.delete(id);
  }

  // Email Logs
  async getEmailLogs(): Promise<EmailLog[]> {
    return Array.from(this.emailLogs.values()).sort((a, b) => 
      new Date(b.sentAt || 0).getTime() - new Date(a.sentAt || 0).getTime()
    );
  }

  async createEmailLog(insertLog: InsertEmailLog): Promise<EmailLog> {
    const id = randomUUID();
    const log: EmailLog = {
      ...insertLog,
      id,
      sentAt: new Date(),
      error: insertLog.error ?? null,
      brandId: insertLog.brandId ?? null,
    };
    this.emailLogs.set(id, log);
    return log;
  }
}

// Database Storage implementation using PostgreSQL
export class DatabaseStorage implements IStorage {
  private db;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is required");
    }
    const client = neon(process.env.DATABASE_URL!);
    this.db = drizzle(client);
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Brands
  async getBrands(): Promise<Brand[]> {
    const result = await this.db.select().from(brands).orderBy(brands.marca);
    return result;
  }

  async getBrand(id: string): Promise<Brand | undefined> {
    const result = await this.db.select().from(brands).where(eq(brands.id, id));
    return result[0];
  }

  async createBrand(insertBrand: InsertBrand): Promise<Brand> {
    const result = await this.db.insert(brands).values(insertBrand).returning();
    return result[0];
  }

  async updateBrand(id: string, brandUpdate: Partial<Brand>): Promise<Brand | undefined> {
    const result = await this.db
      .update(brands)
      .set(brandUpdate)
      .where(eq(brands.id, id))
      .returning();
    return result[0];
  }

  async deleteBrand(id: string): Promise<boolean> {
    const result = await this.db.delete(brands).where(eq(brands.id, id));
    return result.rowCount! > 0;
  }

  async createManyBrands(insertBrands: InsertBrand[]): Promise<Brand[]> {
    if (insertBrands.length === 0) return [];
    const result = await this.db.insert(brands).values(insertBrands).returning();
    return result;
  }

  async getUniqueNiches(): Promise<string[]> {
    try {
      const result = await this.db
        .selectDistinct({ nicho: brands.nicho })
        .from(brands)
        .where(isNotNull(brands.nicho))
        .orderBy(brands.nicho);
      
      return result
        .map(row => row.nicho)
        .filter(nicho => nicho && nicho.trim() !== '');
    } catch (error) {
      console.error('Error fetching unique niches:', error);
      throw error;
    }
  }

  // Content Templates
  async getContentTemplates(): Promise<ContentTemplate[]> {
    const result = await this.db.select().from(contentTemplates);
    return result;
  }

  async getContentTemplateByNiche(nicho: string): Promise<ContentTemplate | undefined> {
    const result = await this.db
      .select()
      .from(contentTemplates)
      .where(sql`lower(${contentTemplates.nicho}) = lower(${nicho})`);
    return result[0];
  }

  async createContentTemplate(insertTemplate: InsertContentTemplate): Promise<ContentTemplate> {
    const result = await this.db.insert(contentTemplates).values(insertTemplate).returning();
    return result[0];
  }

  async updateContentTemplate(id: string, templateUpdate: Partial<ContentTemplate>): Promise<ContentTemplate | undefined> {
    const updateData = { ...templateUpdate, updatedAt: new Date() };
    const result = await this.db
      .update(contentTemplates)
      .set(updateData)
      .where(eq(contentTemplates.id, id))
      .returning();
    return result[0];
  }

  async deleteContentTemplate(id: string): Promise<boolean> {
    const result = await this.db.delete(contentTemplates).where(eq(contentTemplates.id, id));
    return result.rowCount! > 0;
  }

  async upsertContentTemplateByNiche(nicho: string, templateUpdate: Partial<InsertContentTemplate>): Promise<ContentTemplate> {
    const existing = await this.getContentTemplateByNiche(nicho);
    
    if (existing) {
      // Merge video links (dedupe)
      const mergedVideoLinks = existing.videoLinks || [];
      if (templateUpdate.videoLinks) {
        for (const link of templateUpdate.videoLinks) {
          if (!mergedVideoLinks.includes(link)) {
            mergedVideoLinks.push(link);
          }
        }
      }
      
      // Merge video ideas (maintain correspondence with links)
      const mergedVideoIdeas = existing.videoIdeas || [];
      if (templateUpdate.videoIdeas) {
        for (const idea of templateUpdate.videoIdeas) {
          mergedVideoIdeas.push(idea);
        }
      }
      
      // Merge video views (maintain correspondence with links)
      const mergedVideoViews = existing.videoViews || [];
      if (templateUpdate.videoViews) {
        for (const view of templateUpdate.videoViews) {
          mergedVideoViews.push(view);
        }
      }
      
      const updated = await this.updateContentTemplate(existing.id, {
        ...templateUpdate,
        videoLinks: mergedVideoLinks,
        videoIdeas: mergedVideoIdeas,
        videoViews: mergedVideoViews
      });
      return updated!;
    } else {
      const result = await this.db.insert(contentTemplates).values({
        nicho,
        contenido: templateUpdate.contenido || `Content for ${nicho}`,
        idea: templateUpdate.idea,
        videoLinks: templateUpdate.videoLinks
      }).returning();
      return result[0];
    }
  }

  // Followup Templates
  async getFollowupTemplates(): Promise<FollowupTemplate[]> {
    const result = await this.db.select().from(followupTemplates);
    return result;
  }

  async getFollowupTemplate(id: string): Promise<FollowupTemplate | undefined> {
    const result = await this.db.select().from(followupTemplates).where(eq(followupTemplates.id, id));
    return result[0];
  }

  async createFollowupTemplate(insertTemplate: InsertFollowupTemplate): Promise<FollowupTemplate> {
    const result = await this.db.insert(followupTemplates).values(insertTemplate).returning();
    return result[0];
  }

  async updateFollowupTemplate(id: string, templateUpdate: Partial<FollowupTemplate>): Promise<FollowupTemplate | undefined> {
    const updateData = { ...templateUpdate, updatedAt: new Date() };
    const result = await this.db
      .update(followupTemplates)
      .set(updateData)
      .where(eq(followupTemplates.id, id))
      .returning();
    return result[0];
  }

  async deleteFollowupTemplate(id: string): Promise<boolean> {
    const result = await this.db.delete(followupTemplates).where(eq(followupTemplates.id, id));
    return result.rowCount! > 0;
  }

  // Email Logs
  async getEmailLogs(): Promise<EmailLog[]> {
    const result = await this.db.select().from(emailLogs).orderBy(desc(emailLogs.sentAt));
    return result;
  }

  async createEmailLog(insertLog: InsertEmailLog): Promise<EmailLog> {
    const result = await this.db.insert(emailLogs).values(insertLog).returning();
    return result[0];
  }
}

// Use database storage instead of memory storage
export const storage = new DatabaseStorage();
