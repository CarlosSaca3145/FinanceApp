import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertBrandSchema, 
  insertContentTemplateSchema, 
  insertFollowupTemplateSchema,
  insertEmailLogSchema 
} from "@shared/schema";
import { sendEmail, generateEmailHTML } from "./services/email";
import { OpenAIService, type ContentGenerationOptions } from "./services/openai";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Brands routes
  app.get("/api/brands", async (req, res) => {
    try {
      const brands = await storage.getBrands();
      res.json(brands);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch brands" });
    }
  });

  app.post("/api/brands", async (req, res) => {
    try {
      const brandData = insertBrandSchema.parse(req.body);
      const brand = await storage.createBrand(brandData);
      res.json(brand);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid brand data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create brand" });
      }
    }
  });

  app.put("/api/brands/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const brandData = req.body;
      const brand = await storage.updateBrand(id, brandData);
      
      if (!brand) {
        return res.status(404).json({ error: "Brand not found" });
      }
      
      res.json(brand);
    } catch (error) {
      res.status(500).json({ error: "Failed to update brand" });
    }
  });

  app.delete("/api/brands/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteBrand(id);
      
      if (!success) {
        return res.status(404).json({ error: "Brand not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error(`Error deleting brand ${req.params.id}:`, error);
      res.status(500).json({ error: "Failed to delete brand" });
    }
  });

  app.get("/api/brands/niches", async (req, res) => {
    try {
      const niches = await storage.getUniqueNiches();
      res.json(niches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch niches" });
    }
  });

  // Get predefined campaigns
  app.get("/api/brands/campaigns", async (req, res) => {
    try {
      const campaigns = [
        "IFA",
        "MWC", 
        "iPhone",
        "Samsung",
        "BlackFriday",
        "NewYear",
        "NewLaunch"
      ];
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch campaigns" });
    }
  });

  // Add new niche
  app.post("/api/brands/niches", async (req, res) => {
    try {
      const { nicho, niche, name } = req.body;
      
      // Accept nicho (Spanish), niche (English), or name for compatibility
      const nicheValue = nicho || niche || name;
      
      if (!nicheValue || typeof nicheValue !== 'string') {
        console.log("Failed to add niche - no valid niche name provided:", req.body);
        return res.status(400).json({ error: "Niche name is required" });
      }

      console.log("Adding new niche:", nicheValue);

      // Get existing niches to check for duplicates
      const existingNiches = await storage.getUniqueNiches();
      if (existingNiches.some(n => n.toLowerCase() === nicheValue.trim().toLowerCase())) {
        return res.status(409).json({ error: "Niche already exists" });
      }

      // Create a placeholder content template for the new niche to ensure it appears in the niches list
      try {
        await storage.createContentTemplate({
          nicho: nicheValue.trim(),
          contenido: `Template for ${nicheValue.trim()} niche`,
          idea: `Content ideas for ${nicheValue.trim()}`,
          videoLinks: [],
          videoTitles: [],
          fullTemplate: null,
          originalIdea: null,
          proposedIdea: null,
          views: null
        });
      } catch (error) {
        // Template might already exist, that's ok
        console.log(`Content template for ${nicheValue} might already exist`);
      }

      const updatedNiches = await storage.getUniqueNiches();
      res.json({ nicho: nicheValue.trim(), niches: updatedNiches });
    } catch (error) {
      console.error("Error adding niche:", error);
      res.status(500).json({ error: "Failed to add niche" });
    }
  });

  app.post("/api/content-templates/import-excel", async (req, res) => {
    try {
      const { videoLinks, ideas } = req.body;
      
      console.log("Received import data:", { videoLinks: videoLinks?.length || 0, ideas: ideas?.length || 0 });
      
      // Group imported data by niche
      const nicheData: { [niche: string]: { videoLinks: any[], ideas: string[] } } = {};
      
      if (videoLinks && Array.isArray(videoLinks)) {
        videoLinks.forEach((item: any) => {
          if (item.niche) {
            if (!nicheData[item.niche]) {
              nicheData[item.niche] = { videoLinks: [], ideas: [] };
            }
            nicheData[item.niche].videoLinks.push(item);
          }
        });
      }
      
      if (ideas && Array.isArray(ideas)) {
        ideas.forEach((item: any) => {
          if (item.niche) {
            if (!nicheData[item.niche]) {
              nicheData[item.niche] = { videoLinks: [], ideas: [] };
            }
            nicheData[item.niche].ideas.push(item.idea);
          }
        });
      }
      
      let updated = 0;
      let created = 0;
      
      for (const [niche, data] of Object.entries(nicheData)) {
        try {
          // Check if template exists
          const existingTemplates = await storage.getContentTemplates();
          const existingTemplate = existingTemplates.find((t: any) => 
            t.nicho.toLowerCase() === niche.toLowerCase()
          );
          
          if (existingTemplate) {
            // Update existing template
            const updateData: any = {};
            
            if (data.videoLinks.length > 0) {
              const newLinks = data.videoLinks.map(v => v.link);
              const newTitles = data.videoLinks.map(v => v.title || '');
              const newIdeas = data.videoLinks.map(v => v.ideas || '');
              const newViews = data.videoLinks.map(v => v.views || '');
              
              updateData.videoLinks = [...(existingTemplate.videoLinks || []), ...newLinks];
              updateData.videoTitles = [...(existingTemplate.videoTitles || []), ...newTitles];
              updateData.videoIdeas = [...(existingTemplate.videoIdeas || []), ...newIdeas];
              updateData.videoViews = [...(existingTemplate.videoViews || []), ...newViews];
            }
            
            if (data.ideas.length > 0) {
              const newIdeasText = data.ideas.map(idea => `• In order to achieve good reach with your product, I propose the following content idea: "${idea}"`).join('\n');
              updateData.idea = existingTemplate.idea ? `${existingTemplate.idea}\n${newIdeasText}` : newIdeasText;
            }
            
            await storage.updateContentTemplate(existingTemplate.id, updateData);
            updated++;
            console.log(`Updated template for niche: ${niche}`);
          } else {
            // Create new template
            const templateData: any = {
              nicho: niche,
              contenido: `Content for ${niche}`,
              idea: '',
              videoLinks: [],
              videoTitles: [],
              videoIdeas: [],
              videoViews: [],
              fullTemplate: null,
              originalIdea: null,
              proposedIdea: null,
              views: null
            };
            
            if (data.videoLinks.length > 0) {
              templateData.videoLinks = data.videoLinks.map(v => v.link);
              templateData.videoTitles = data.videoLinks.map(v => v.title || '');
              templateData.videoIdeas = data.videoLinks.map(v => v.ideas || '');
              templateData.videoViews = data.videoLinks.map(v => v.views || '');
            }
            
            if (data.ideas.length > 0) {
              templateData.idea = data.ideas.map(idea => `• In order to achieve good reach with your product, I propose the following content idea: "${idea}"`).join('\n');
            }
            
            await storage.createContentTemplate(templateData);
            created++;
            console.log(`Created new template for niche: ${niche}`);
          }
        } catch (error) {
          console.error(`Error processing template for ${niche}:`, error);
        }
      }
      
      res.json({ 
        message: "Templates imported successfully", 
        updated, 
        created,
        total: Object.keys(nicheData).length,
        totalVideoLinks: videoLinks?.length || 0,
        totalIdeas: ideas?.length || 0
      });
    } catch (error) {
      console.error("Import error:", error);
      res.status(500).json({ error: "Failed to import templates" });
    }
  });

  // Content Templates routes
  app.get("/api/content-templates", async (req, res) => {
    try {
      const templates = await storage.getContentTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch content templates" });
    }
  });

  app.post("/api/content-templates", async (req, res) => {
    try {
      const templateData = insertContentTemplateSchema.parse(req.body);
      const template = await storage.createContentTemplate(templateData);
      res.json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid template data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create template" });
      }
    }
  });

  app.put("/api/content-templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const templateData = req.body;
      const template = await storage.updateContentTemplate(id, templateData);
      
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      res.status(500).json({ error: "Failed to update template" });
    }
  });

  app.patch("/api/content-templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const templateData = req.body;
      
      console.log(`[PATCH] Updating template ${id} with data:`, JSON.stringify(templateData, null, 2));
      
      const template = await storage.updateContentTemplate(id, templateData);
      
      if (!template) {
        console.log(`[PATCH] Template ${id} not found`);
        return res.status(404).json({ error: "Template not found" });
      }
      
      console.log(`[PATCH] Template ${template.id} updated successfully. New videoLinks:`, template.videoLinks);
      console.log(`[PATCH] Template ${template.id} updated successfully. New videoIdeas:`, template.videoIdeas);
      
      res.json(template);
    } catch (error) {
      console.error(`[PATCH] Error updating template:`, error);
      res.status(500).json({ error: "Failed to update template" });
    }
  });

  app.delete("/api/content-templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteContentTemplate(id);
      
      if (!success) {
        return res.status(404).json({ error: "Template not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete template" });
    }
  });

  // Followup Templates routes
  app.get("/api/followup-templates", async (req, res) => {
    try {
      const templates = await storage.getFollowupTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch followup templates" });
    }
  });

  app.post("/api/followup-templates", async (req, res) => {
    try {
      const templateData = insertFollowupTemplateSchema.parse(req.body);
      const template = await storage.createFollowupTemplate(templateData);
      res.json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid template data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create template" });
      }
    }
  });

  // Generate follow-up with AI
  app.post("/api/generate-followup", async (req, res) => {
    try {
      const { prompt } = req.body;
      
      if (!prompt || typeof prompt !== 'string') {
        return res.status(400).json({ error: "Prompt is required" });
      }

      // Use OpenAI integration to generate follow-up
      const OpenAI = (await import("openai")).default;
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      
      const systemPrompt = `You are a professional email follow-up expert. Generate a polite, professional follow-up email based on the user's requirements. The follow-up should be:
      1. Professional and courteous
      2. Brief but effective  
      3. Include a gentle reminder about the previous email
      4. Express continued interest in collaboration
      5. Maintain a positive tone
      
      Respond with JSON in this format: { "followup": "the generated follow-up message" }`;

      const response = await openai.chat.completions.create({
        // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        model: "gpt-5",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        max_completion_tokens: 500,
      });

      const content = response.choices[0].message.content;
      if (!content) {
        throw new Error("No content generated");
      }
      
      const result = JSON.parse(content);
      res.json({ followup: result.followup });
    } catch (error) {
      console.error("Error generating follow-up:", error);
      res.status(500).json({ error: "Failed to generate follow-up" });
    }
  });

  // Generate content idea with AI
  app.post("/api/generate-idea", async (req, res) => {
    try {
      const { niche, prompt } = req.body;
      
      if (!prompt || typeof prompt !== 'string') {
        return res.status(400).json({ error: "Prompt is required" });
      }
      
      if (!niche || typeof niche !== 'string') {
        return res.status(400).json({ error: "Niche is required" });
      }

      // Use OpenAI integration to generate content idea
      const OpenAI = (await import("openai")).default;
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      
      const systemPrompt = `You are a creative content specialist who generates engaging content ideas for brand partnerships and campaigns. Generate a specific, actionable content idea based on the user's requirements for the ${niche} niche. The idea should be:
      1. Creative and engaging
      2. Suitable for the ${niche} industry
      3. Practical and achievable
      4. Brand-friendly for partnerships
      5. Clear and concise (2-3 sentences maximum)
      
      Respond with JSON in this format: { "idea": "the generated content idea" }`;


      const response = await openai.chat.completions.create({
        // Using gpt-5-mini for faster, more direct responses for content generation
        model: "gpt-5-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        max_completion_tokens: 1000,
      });


      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error("No content generated");
      }
      
      const result = JSON.parse(content);
      res.json({ idea: result.idea });
    } catch (error) {
      console.error("Error generating idea:", error);
      res.status(500).json({ error: "Failed to generate idea" });
    }
  });

  // Email sending route
  app.post("/api/send-email", async (req, res) => {
    try {
      const { brandId, templateType, subjectOverride, htmlOverride, nicheIdeaUsed } = req.body;
      
      const brand = await storage.getBrand(brandId);
      if (!brand) {
        return res.status(404).json({ error: "Brand not found" });
      }

      // Validate that the brand has an email address
      if (!brand.correo || !brand.correo.trim()) {
        return res.status(400).json({ error: "Brand does not have a valid email address" });
      }

      let htmlBody = "";
      let subject = "";

      // Use AI-generated content if provided, otherwise use templates
      if (htmlOverride && subjectOverride) {
        htmlBody = htmlOverride;
        subject = subjectOverride;
      } else {
        if (templateType === "followup") {
          const followupTemplates = await storage.getFollowupTemplates();
          const followupTemplate = followupTemplates[0]; // Use first available template
          
          if (followupTemplate) {
            const seguimientoHTML = `<p>${followupTemplate.template.replace(/{{contacto}}/g, brand.contacto || "")}</p>`;
            htmlBody = generateEmailHTML(
              brand.contacto || "",
              brand.marca,
              brand.nicho,
              "seguimiento de correo",
              "",
              seguimientoHTML,
              undefined, // videoLink
              undefined, // views
              undefined  // contentIdea
            );
          }
          subject = `Follow-up: Collaboration — ${brand.marca}`;
        } else {
          // Regular collaboration email
          const contentTemplate = await storage.getContentTemplateByNiche(brand.nicho);
          const contenidoTexto = contentTemplate?.contenido || "";
          
          // Get first video link and views from template
          const videoLink = contentTemplate?.videoLinks?.[0] || "";
          const views = contentTemplate?.views || "";
          const contentIdea = contentTemplate?.idea || "";
          
          htmlBody = generateEmailHTML(
            brand.contacto || "",
            brand.marca,
            brand.nicho,
            brand.campania || "",
            contenidoTexto,
            undefined, // seguimientoHTML
            videoLink,
            views,
            contentIdea
          );
          subject = `Collaboration ${brand.campania || ""} — ${brand.marca}`;
        }
      }

      const emailResult = await sendEmail({
        to: brand.correo,
        subject,
        htmlBody,
        name: "Saca Tech",
        from: "c@saca.technology",
      });

      if (emailResult.success) {
        // Update brand status
        await storage.updateBrand(brandId, {
          estado: "✅ Enviado",
          fechaEnvio: new Date(),
        });

        // Log the email with additional AI context
        await storage.createEmailLog({
          brandId,
          recipient: brand.correo,
          subject,
          htmlBody,
          status: "sent",
          ...(nicheIdeaUsed && { error: `AI Niche Idea Used: ${nicheIdeaUsed}` }) // Store niche idea in error field as context
        });

        res.json({ success: true, message: `Email sent to ${brand.contacto || brand.correo}` });
      } else {
        // Log the failed email
        await storage.createEmailLog({
          brandId,
          recipient: brand.correo,
          subject,
          htmlBody,
          status: "failed",
          error: emailResult.error,
        });

        res.status(500).json({ error: `Failed to send email: ${emailResult.error}` });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to send email" });
    }
  });

  // Email logs route
  app.get("/api/email-logs", async (req, res) => {
    try {
      const logs = await storage.getEmailLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch email logs" });
    }
  });

  // AI Content Generation routes
  app.post("/api/ai/generate-email", async (req, res) => {
    try {
      const { brandName, industry, tone, purpose, additionalContext } = req.body;
      
      const options: ContentGenerationOptions = {
        brandName,
        industry,
        tone,
        purpose,
        additionalContext
      };
      
      const content = await OpenAIService.generateEmailContent(options);
      res.json(content);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate email content: " + (error as Error).message });
    }
  });

  app.post("/api/ai/generate-subjects", async (req, res) => {
    try {
      const { brandName, purpose, count = 3 } = req.body;
      
      const subjects = await OpenAIService.generateSubjectLines(brandName, purpose, count);
      res.json({ subjects });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate subject lines: " + (error as Error).message });
    }
  });

  app.post("/api/ai/improve-template", async (req, res) => {
    try {
      const { currentContent, improvements } = req.body;
      
      const improvedContent = await OpenAIService.improveTemplate(currentContent, improvements);
      res.json({ improvedContent });
    } catch (error) {
      res.status(500).json({ error: "Failed to improve template: " + (error as Error).message });
    }
  });

  app.post("/api/ai/analyze-response", async (req, res) => {
    try {
      const { emailContent } = req.body;
      
      const analysis = await OpenAIService.analyzeEmailResponse(emailContent);
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: "Failed to analyze email: " + (error as Error).message });
    }
  });

  app.post("/api/ai/generate-niche-ideas", async (req, res) => {
    try {
      const { niche, brandName, customSuggestion } = req.body;
      
      const ideas = await OpenAIService.generateNicheIdeas(niche, brandName, customSuggestion);
      res.json({ ideas });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate niche ideas: " + (error as Error).message });
    }
  });

  app.post("/api/ai/regenerate-email", async (req, res) => {
    try {
      const { brandName, industry, nicheIdea, selectedVideoLink } = req.body;
      
      // Generate only the content section, not the full email
      const contentSection = await OpenAIService.generateContentSection(nicheIdea, industry, brandName, selectedVideoLink);
      
      res.json({ 
        content: contentSection,
        subject: `Collaboration — ${brandName}`
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to regenerate email: " + (error as Error).message });
    }
  });

  // Import routes
  app.post("/api/import/brands", async (req, res) => {
    try {
      const importSchema = z.object({
        items: z.array(insertBrandSchema)
      });
      
      const { items } = importSchema.parse(req.body);
      const createdBrands = await storage.createManyBrands(items);
      
      res.json({
        success: true,
        created: createdBrands.length,
        brands: createdBrands
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid brand data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to import brands: " + (error as Error).message });
      }
    }
  });

  app.post("/api/import/niche-assets", async (req, res) => {
    try {
      const importSchema = z.object({
        items: z.array(z.object({
          nicho: z.string(),
          idea: z.string().optional(),
          videoLinks: z.array(z.string()).optional()
        }))
      });
      
      const { items } = importSchema.parse(req.body);
      const results = [];
      
      for (const item of items) {
        const template = await storage.upsertContentTemplateByNiche(item.nicho, {
          idea: item.idea,
          videoLinks: item.videoLinks
        });
        results.push(template);
      }
      
      res.json({
        success: true,
        processed: results.length,
        templates: results
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid niche asset data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to import niche assets: " + (error as Error).message });
      }
    }
  });

  // Dashboard stats route
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const brands = await storage.getBrands();
      const emailLogs = await storage.getEmailLogs();

      const totalBrands = brands.length;
      const emailsSent = emailLogs.filter(log => log.status === "sent").length;
      const responsesReceived = brands.filter(brand => brand.estado === "Responded").length;
      const activeCampaigns = new Set(brands.map(brand => brand.campania).filter(Boolean)).size;
      
      const responseRate = emailsSent > 0 ? ((responsesReceived / emailsSent) * 100).toFixed(1) : "0";

      res.json({
        totalBrands,
        emailsSent,
        responseRate: `${responseRate}%`,
        activeCampaigns,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
