import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const brands = pgTable("brands", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marca: text("marca").notNull(),
  correo: text("correo").notNull(),
  correos: text("correos").array(), // Additional emails array
  contacto: text("contacto"),
  contactos: text("contactos").array(), // Additional contacts array
  nicho: text("nicho").notNull(),
  campania: text("campania"),
  estado: text("estado").default("Pending"),
  fechaEnvio: timestamp("fecha_envio"),
  seguimientoModelo: text("seguimiento_modelo"),
  notes: text("notes"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const contentTemplates = pgTable("content_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nicho: text("nicho").notNull().unique(),
  contenido: text("contenido").notNull(),
  idea: text("idea"),
  videoLinks: text("video_links").array(),
  videoTitles: text("video_titles").array(), // Titles for each video link
  videoIdeas: text("video_ideas").array(), // Ideas for each video link
  videoViews: text("video_views").array(), // Views for each video link
  fullTemplate: text("full_template"), // Complete template from Excel
  originalIdea: text("original_idea"), // Extracted original idea
  proposedIdea: text("proposed_idea"), // Extracted proposed idea
  views: text("views"), // Video views metrics
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`),
});

export const followupTemplates = pgTable("followup_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  template: text("template").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`),
});

export const emailLogs = pgTable("email_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  brandId: varchar("brand_id").references(() => brands.id, { onDelete: 'cascade' }),
  recipient: text("recipient").notNull(),
  subject: text("subject").notNull(),
  htmlBody: text("html_body").notNull(),
  status: text("status").notNull(), // sent, failed, pending
  sentAt: timestamp("sent_at").default(sql`now()`),
  error: text("error"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertBrandSchema = createInsertSchema(brands).omit({
  id: true,
  createdAt: true,
});

export const insertContentTemplateSchema = createInsertSchema(contentTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFollowupTemplateSchema = createInsertSchema(followupTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmailLogSchema = createInsertSchema(emailLogs).omit({
  id: true,
  sentAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertBrand = z.infer<typeof insertBrandSchema>;
export type Brand = typeof brands.$inferSelect;

export type InsertContentTemplate = z.infer<typeof insertContentTemplateSchema>;
export type ContentTemplate = typeof contentTemplates.$inferSelect;

export type InsertFollowupTemplate = z.infer<typeof insertFollowupTemplateSchema>;
export type FollowupTemplate = typeof followupTemplates.$inferSelect;

export type InsertEmailLog = z.infer<typeof insertEmailLogSchema>;
export type EmailLog = typeof emailLogs.$inferSelect;
