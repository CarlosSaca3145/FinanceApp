import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ResponsiveLayout } from "@/components/layout/responsive-layout";
import { Dashboard } from "@/pages/dashboard";
import { Brands } from "@/pages/brands";
import { ContentTemplates } from "@/pages/content-templates";
import NotFound from "@/pages/not-found";

function Router() {
  const [location] = useLocation();
  
  // Determine active tab from current route
  const getActiveTab = () => {
    if (location === "/brands") return "brands";
    if (location === "/content-templates") return "content";
    return "dashboard";
  };

  return (
    <ResponsiveLayout activeTab={getActiveTab()}>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/brands" component={Brands} />
        <Route path="/content-templates" component={ContentTemplates} />
        <Route component={NotFound} />
      </Switch>
    </ResponsiveLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
