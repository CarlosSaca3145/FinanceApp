import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building, Mail, TrendingUp, Megaphone, ArrowUp, ArrowDown, PlaneTakeoff } from "lucide-react";
import { getDashboardStats } from "@/lib/api";

export function Dashboard() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: () => import("@/lib/api").then(m => m.getDashboardStats()),
  });

  if (isLoading) {
    return (
      <div className="flex-1 overflow-auto">
        <header className="bg-card border-b border-border px-4 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl lg:text-2xl font-bold text-foreground">Dashboard</h2>
              <p className="text-sm lg:text-base text-muted-foreground">Campaign overview and performance metrics</p>
            </div>
          </div>
        </header>
        <div className="p-4 lg:p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4 lg:p-6">
                  <div className="h-16 lg:h-20 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto">
      <header className="bg-card border-b border-border px-4 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-foreground">Dashboard</h2>
            <p className="text-sm lg:text-base text-muted-foreground">Campaign overview and performance metrics</p>
          </div>
          <Button className="flex items-center justify-center space-x-2 w-full sm:w-auto" data-testid="button-bulk-send">
            <PlaneTakeoff className="h-4 w-4" />
            <span>Send Emails</span>
          </Button>
        </div>
      </header>

      <div className="p-4 lg:p-8 space-y-6 lg:space-y-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          <Card>
            <CardContent className="p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-muted-foreground text-xs lg:text-sm font-medium">Total Brands</p>
                  <p className="text-xl lg:text-2xl font-bold text-foreground" data-testid="stat-total-brands">
                    {stats?.totalBrands || 0}
                  </p>
                </div>
                <div className="w-10 h-10 lg:w-12 lg:h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
              <div className="mt-3 lg:mt-4 flex items-center text-xs lg:text-sm">
                <span className="text-green-600 dark:text-green-400 flex items-center">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  12%
                </span>
                <span className="text-muted-foreground ml-1">vs last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-muted-foreground text-xs lg:text-sm font-medium">Emails Sent</p>
                  <p className="text-xl lg:text-2xl font-bold text-foreground" data-testid="stat-emails-sent">
                    {stats?.emailsSent || 0}
                  </p>
                </div>
                <div className="w-10 h-10 lg:w-12 lg:h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="h-5 w-5 lg:h-6 lg:w-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
              <div className="mt-3 lg:mt-4 flex items-center text-xs lg:text-sm">
                <span className="text-green-600 dark:text-green-400 flex items-center">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  8%
                </span>
                <span className="text-muted-foreground ml-1">vs last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-muted-foreground text-xs lg:text-sm font-medium">Response Rate</p>
                  <p className="text-xl lg:text-2xl font-bold text-foreground" data-testid="stat-response-rate">
                    {stats?.responseRate || "0%"}
                  </p>
                </div>
                <div className="w-10 h-10 lg:w-12 lg:h-12 bg-yellow-100 dark:bg-yellow-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="h-5 w-5 lg:h-6 lg:w-6 text-yellow-600 dark:text-yellow-400" />
                </div>
              </div>
              <div className="mt-3 lg:mt-4 flex items-center text-xs lg:text-sm">
                <span className="text-green-600 dark:text-green-400 flex items-center">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  4%
                </span>
                <span className="text-muted-foreground ml-1">vs last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-muted-foreground text-xs lg:text-sm font-medium">Active Campaigns</p>
                  <p className="text-xl lg:text-2xl font-bold text-foreground" data-testid="stat-active-campaigns">
                    {stats?.activeCampaigns || 0}
                  </p>
                </div>
                <div className="w-10 h-10 lg:w-12 lg:h-12 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Megaphone className="h-5 w-5 lg:h-6 lg:w-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
              <div className="mt-3 lg:mt-4 flex items-center text-xs lg:text-sm">
                <span className="text-red-600 dark:text-red-400 flex items-center">
                  <ArrowDown className="h-3 w-3 mr-1" />
                  2%
                </span>
                <span className="text-muted-foreground ml-1">vs last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4" data-testid="recent-activity-list">
                <div className="text-center py-8 text-muted-foreground">
                  <Mail className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No recent activity</p>
                  <p className="text-xs">Activity will appear here when you start sending emails</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4" data-testid="campaign-performance-list">
                <div className="text-center py-8 text-muted-foreground">
                  <TrendingUp className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No campaign data</p>
                  <p className="text-xs">Campaign performance will appear here after sending emails</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
