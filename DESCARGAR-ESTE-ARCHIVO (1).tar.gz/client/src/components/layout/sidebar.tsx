import { cn } from "@/lib/utils";
import { BarChart3, Building, Mail, FileText, Settings, PlaneTakeoff } from "lucide-react";
import { Link } from "wouter";

interface SidebarProps {
  activeTab: string;
  onTabChange?: (tab: string) => void; // Made optional since we'll use Link navigation
}

const navigation = [
  { id: "dashboard", label: "Dashboard", icon: BarChart3, path: "/" },
  { id: "brands", label: "Brands", icon: Building, path: "/brands" },
  { id: "content", label: "Content Templates", icon: FileText, path: "/content-templates" },
];

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <PlaneTakeoff className="text-primary-foreground h-4 w-4" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">Brand Campaign Manager</h1>
            <p className="text-xs text-muted-foreground">Saca Tech</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <Link 
                  href={item.path}
                  className={cn(
                    "w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors font-medium no-underline",
                    activeTab === item.id
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                  data-testid={`nav-${item.id}`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
            <span className="text-muted-foreground text-sm font-medium">CS</span>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">Carlos Saca</p>
            <p className="text-xs text-muted-foreground">c@saca.technology</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
