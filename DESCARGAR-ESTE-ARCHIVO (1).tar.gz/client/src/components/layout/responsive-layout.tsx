import { useState } from "react";
import { cn } from "@/lib/utils";
import { BarChart3, Building, FileText, PlaneTakeoff, Menu, X } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

interface ResponsiveLayoutProps {
  activeTab: string;
  children: React.ReactNode;
}

const navigation = [
  { id: "dashboard", label: "Dashboard", icon: BarChart3, path: "/" },
  { id: "brands", label: "Brands", icon: Building, path: "/brands" },
  { id: "content", label: "Content Templates", icon: FileText, path: "/content-templates" },
];

export function ResponsiveLayout({ activeTab, children }: ResponsiveLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  return (
    <div className="flex h-screen bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 bg-card border-r border-border flex-col">
        <div className="p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <PlaneTakeoff className="text-primary-foreground h-4 w-4" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">Brand Campaign Manager</h1>
              <p className="text-xs text-muted-foreground">Saca Tech</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.id}>
                  <Link 
                    href={item.path}
                    className={cn(
                      "w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors font-medium no-underline",
                      activeTab === item.id
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                    )}
                    data-testid={`nav-${item.id}`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        
        <div className="p-4 border-t border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
              <span className="text-muted-foreground text-sm font-medium">CS</span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Carlos Saca</p>
              <p className="text-xs text-muted-foreground">c@saca.technology</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={closeMobileMenu}
        />
      )}

      {/* Mobile Sidebar */}
      <aside className={cn(
        "lg:hidden fixed left-0 top-0 h-full w-64 bg-card border-r border-border flex flex-col z-50 transition-transform duration-200",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <PlaneTakeoff className="text-primary-foreground h-4 w-4" />
            </div>
            <div>
              <h1 className="text-base font-semibold text-foreground">Brand Campaign</h1>
              <p className="text-xs text-muted-foreground">Saca Tech</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={closeMobileMenu}
            data-testid="close-mobile-menu"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.id}>
                  <Link 
                    href={item.path}
                    onClick={closeMobileMenu}
                    className={cn(
                      "w-full flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors font-medium no-underline",
                      activeTab === item.id
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                    )}
                    data-testid={`mobile-nav-${item.id}`}
                  >
                    <Icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        
        <div className="p-4 border-t border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
              <span className="text-muted-foreground text-sm font-medium">CS</span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Carlos Saca</p>
              <p className="text-xs text-muted-foreground">c@saca.technology</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Top Bar */}
        <header className="lg:hidden bg-card border-b border-border p-4 flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setIsMobileMenuOpen(true)}
            data-testid="open-mobile-menu"
          >
            <Menu className="h-5 w-5" />
          </Button>
          
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
              <PlaneTakeoff className="text-primary-foreground h-3 w-3" />
            </div>
            <span className="text-sm font-semibold text-foreground">Brand Campaign</span>
          </div>
          
          <div className="w-8" /> {/* Spacer for centering */}
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}