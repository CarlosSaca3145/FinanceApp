import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { sendEmailToBrand, getContentTemplates, apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, RefreshCw } from "lucide-react";
import type { Brand } from "@shared/schema";

interface EmailComposerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  brand: Brand | null;
}

export function EmailComposerModal({ open, onOpenChange, brand }: EmailComposerModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [templateType, setTemplateType] = useState<"general" | "followup">("general");
  const [customSubject, setCustomSubject] = useState("");
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [isGeneratingSuggestions, setIsGeneratingSuggestions] = useState(false);
  const [nicheIdeas, setNicheIdeas] = useState<string[]>([]);
  const [customNicheIdea, setCustomNicheIdea] = useState("");
  const [selectedNicheIdea, setSelectedNicheIdea] = useState("");
  const [isGeneratingNicheIdeas, setIsGeneratingNicheIdeas] = useState(false);
  const [generatedContentSection, setGeneratedContentSection] = useState("");
  const [isRegeneratingEmail, setIsRegeneratingEmail] = useState(false);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const [selectedVideoLink, setSelectedVideoLink] = useState("");
  
  const { data: contentTemplates = [] } = useQuery({
    queryKey: ["/api/content-templates"],
    queryFn: () => import("@/lib/api").then(m => m.getContentTemplatesTyped()),
    enabled: open && !!brand,
  });

  const sendEmailMutation = useMutation({
    mutationFn: sendEmailToBrand,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/brands"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Email sent successfully",
      });
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send email",
        variant: "destructive",
      });
    },
  });

  const generateNicheIdeas = async (suggestion?: string) => {
    if (!brand) return;
    
    setIsGeneratingNicheIdeas(true);
    try {
      const response = await apiRequest("POST", "/api/ai/generate-niche-ideas", {
        niche: brand.nicho,
        brandName: brand.marca,
        customSuggestion: suggestion || customNicheIdea || undefined
      });
      
      const data = await response.json();
      setNicheIdeas(data.ideas || []);
      toast({
        title: "Success",
        description: suggestion ? "AI ideas generated based on your suggestion!" : "AI niche ideas generated!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate niche ideas. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingNicheIdeas(false);
    }
  };

  const regenerateEmailWithIdea = async (idea: string) => {
    if (!brand) return;
    
    setIsRegeneratingEmail(true);
    try {
      const response = await apiRequest("POST", "/api/ai/regenerate-email", {
        brandName: brand.marca,
        industry: brand.nicho,
        nicheIdea: idea,
        selectedVideoLink: selectedVideoLink || undefined
      });
      
      const data = await response.json();
      setGeneratedContentSection(data.content);
      toast({
        title: "Success",
        description: "Content section updated with your idea!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to regenerate content. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsRegeneratingEmail(false);
    }
  };

  const handleCustomIdeaSubmit = () => {
    if (!customNicheIdea.trim()) {
      toast({
        title: "Error",
        description: "Please write your idea first",
        variant: "destructive",
      });
      return;
    }
    setSelectedNicheIdea(customNicheIdea);
    regenerateEmailWithIdea(customNicheIdea);
  };

  const generatePreview = () => {
    if (!brand) return "";

    // Get video link and views from content template
    const contentTemplate = contentTemplates.find(
      (t: any) => t.nicho.toLowerCase() === brand.nicho.toLowerCase()
    );
    
    const videoLink = selectedVideoLink && selectedVideoLink !== "none" ? selectedVideoLink : (contentTemplate?.videoLinks?.[0] || "");
    const views = contentTemplate?.views || "";
    
    // Extract content ideas from template
    let firstIdea = "";
    let secondIdea = "";
    
    // Get the title for the selected video link (this becomes the firstIdea)
    if (videoLink && videoLink !== "none" && contentTemplate) {
      // Find the index of the selected video link
      const videoIndex = contentTemplate.videoLinks?.findIndex((link: string) => link === videoLink);
      if (videoIndex !== undefined && videoIndex >= 0) {
        // Use the corresponding video title
        if (contentTemplate.videoTitles && contentTemplate.videoTitles[videoIndex]) {
          firstIdea = contentTemplate.videoTitles[videoIndex];
        } else {
          // Fallback to a default title format
          firstIdea = `${brand.nicho} Review - Product Demonstration`;
        }
      }
    }
    
    // Set the secondIdea based on user selection or extract from template
    if (selectedNicheIdea) {
      secondIdea = selectedNicheIdea;
    } else if (contentTemplate?.idea) {
      const ideaText = contentTemplate.idea;
      
      // Second idea: look for text after "I propose the following content idea:"
      const secondIdeaMatch = ideaText.match(/I propose the following content idea:\s*["""']\s*([^"""']+?)\s*["""']/);
      if (secondIdeaMatch) {
        secondIdea = secondIdeaMatch[1].trim();
      } else if (!ideaText.includes("I want to show you how we have integrated")) {
        // If it's a simple idea (not the full template format), use it directly
        const lines = ideaText.split('\n').filter(line => line.trim());
        const firstLine = lines[0]?.replace(/^•\s*/, '').trim();
        if (firstLine && firstLine.length > 3 && firstLine.length < 150) {
          secondIdea = firstLine;
        }
      }
    }
    
    // Get video views info for the selected video link
    const videoViews = (() => {
      if (!videoLink || videoLink === "none") return "";
      
      const template = contentTemplates.find(
        (t: any) => t.nicho.toLowerCase() === brand.nicho.toLowerCase()
      );
      
      if (!template?.videoLinks) return "";
      
      const videoIndex = template.videoLinks.findIndex((link: string) => link === videoLink);
      if (videoIndex >= 0 && template.videoViews && template.videoViews[videoIndex]) {
        return template.videoViews[videoIndex];
      }
      
      // Fallback to general views if specific video views not found
      return template.views || "";
    })();

    if (templateType === "followup") {
      return `
        <p>Hi ${brand.contacto || 'team'},</p>
        <p>I'm Carlos Saca from Saca Tech (@saca.technology).</p>
        <p>I wanted to follow up on my previous email regarding our collaboration opportunity. We're still very interested in working with your brand and showcasing your products to our engaged audience.</p>
        <p>Would you be available for a quick call this week to discuss the partnership?</p>
        <p>I look forward to discussing this collaboration further with you.</p>
        <p>Best regards,<br><strong>Carlos Saca</strong><br>Saca Tech<br>@saca.technology</p>
      `;
    }

    return `
      <p>Hi ${brand.contacto || 'team'},</p>
      <p>I'm Carlos Saca from Saca Tech (@saca.technology).</p>
      ${brand.campania && brand.campania.toLowerCase() !== "general" ? 
        `<p>Regarding the campaign: <strong>${brand.campania}</strong>, we would love to collaborate with you during this period.</p>` : ''}
      <p>We collaborate with multiple brands across various niches (drones, microphones, robot vacuums, smartphones), achieving great reach and impact.</p>
      ${videoLink && (firstIdea || secondIdea) ? 
        `<p>I want to show you how we have integrated content with the idea of "${firstIdea}" according to the link: <a href="${videoLink}" target="_blank">${videoLink}</a>${videoViews ? ` with ${videoViews}` : ''}. In order to achieve good reach with your product, I propose the following content idea: "${secondIdea}". It is just one of the many ideas we could discuss together.</p>` : ''}
      <p>I look forward to discussing this collaboration further with you.</p>
      <p>Best regards,<br><strong>Carlos Saca</strong><br>Saca Tech<br>@saca.technology</p>
    `;
  };

  const handleSendEmail = () => {
    if (!brand) return;
    
    const emailData: any = {
      brandId: brand.id,
      templateType,
      htmlOverride: generatePreview(), // Always use frontend preview
      subjectOverride: subject,
    };
    
    // Include niche idea if used
    if (selectedNicheIdea || customNicheIdea) {
      emailData.nicheIdeaUsed = selectedNicheIdea || customNicheIdea;
    }
    
    sendEmailMutation.mutate(emailData);
  };

  const generateSubjectSuggestions = async () => {
    if (!brand) return;
    
    setIsGeneratingSuggestions(true);
    try {
      const response = await apiRequest("POST", "/api/ai/generate-subjects", {
        brandName: brand.marca,
        purpose: templateType === "followup" ? "follow-up email" : "brand collaboration outreach",
        count: 3
      });
      
      const data = await response.json();
      setAiSuggestions(data.subjects || []);
      toast({
        title: "Success",
        description: "AI subject suggestions generated!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate subject suggestions. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingSuggestions(false);
    }
  };

  // Reset all states when brand or template changes
  useEffect(() => {
    setCustomSubject("");
    setAiSuggestions([]);
    setNicheIdeas([]);
    setSelectedNicheIdea("");
    setGeneratedContentSection("");
    setSelectedVideoLink("");
    setCustomNicheIdea("");
    setShowAdvancedOptions(false);
  }, [brand, templateType]);

  // Pre-fill with template data when brand and templates are available
  useEffect(() => {
    if (brand && contentTemplates.length > 0) {
      const brandContentTemplate = contentTemplates.find(
        (t: any) => t.nicho.toLowerCase() === brand.nicho.toLowerCase()
      );
      if (brandContentTemplate) {
        // Pre-fill the idea field if available
        if (brandContentTemplate.idea) {
          setCustomNicheIdea(brandContentTemplate.idea);
        }
        // Set first video link as default if available
        if (brandContentTemplate.videoLinks && brandContentTemplate.videoLinks.length > 0) {
          setSelectedVideoLink(brandContentTemplate.videoLinks[0]);
        }
      }
    }
  }, [brand?.nicho, contentTemplates.length]); // Only depend on brand niche and template count


  if (!brand) return null;

  const defaultSubject = templateType === "followup" 
    ? `Follow-up: Collaboration — ${brand.marca}`
    : `Collaboration ${brand.campania || ""} — ${brand.marca}`;
    
  const subject = customSubject || defaultSubject;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Compose Email</DialogTitle>
          <DialogDescription>
            Send personalized outreach email with AI-generated suggestions
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Email Form */}
          <div className="space-y-6">
            <div>
              <Label>To</Label>
              <Input
                value={brand.correo}
                readOnly
                className="bg-muted"
                data-testid="input-email-to"
              />
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>Subject</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={generateSubjectSuggestions}
                  disabled={isGeneratingSuggestions}
                  className="text-xs"
                  data-testid="button-generate-subjects"
                >
                  <Sparkles className="h-3 w-3 mr-1" />
                  {isGeneratingSuggestions ? "Generating..." : "AI Suggestions"}
                </Button>
              </div>
              <Input
                value={customSubject}
                onChange={(e) => setCustomSubject(e.target.value)}
                placeholder={defaultSubject}
                data-testid="input-email-subject"
              />
              {aiSuggestions.length > 0 && (
                <div className="mt-3 space-y-2">
                  <Label className="text-xs text-muted-foreground">AI Suggestions (click to use):</Label>
                  {aiSuggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      type="button"
                      className="block w-full text-left px-3 py-2 text-xs bg-muted/50 hover:bg-muted rounded border transition-colors"
                      onClick={() => setCustomSubject(suggestion)}
                      data-testid={`suggestion-${index}`}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <div>
              <Label>Template</Label>
              <Select value={templateType} onValueChange={(value: "general" | "followup") => setTemplateType(value)}>
                <SelectTrigger data-testid="select-template-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General Collaboration</SelectItem>
                  <SelectItem value="followup">Follow-up</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Customization Options for General Template */}
            {templateType === "general" && (
              <div className="space-y-4">
                <Label className="text-base font-medium">Customize Content for {brand.nicho}</Label>
                
                {/* Custom Idea Input */}
                <div className="space-y-3 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                  <Label className="text-sm font-medium">Your Content Idea (Optional)</Label>
                  <Input
                    value={customNicheIdea}
                    onChange={(e) => setCustomNicheIdea(e.target.value)}
                    placeholder="e.g., 'Test waterproof feature in swimming pool'"
                    className="flex-1"
                    data-testid="input-custom-niche-idea"
                  />
                  <div className="flex space-x-2">
                    <Button
                      type="button"
                      onClick={() => generateNicheIdeas(customNicheIdea)}
                      disabled={isGeneratingNicheIdeas || !customNicheIdea.trim()}
                      variant="default"
                      size="sm"
                      data-testid="button-generate-with-suggestion"
                    >
                      <Sparkles className="h-4 w-4 mr-1" />
                      {isGeneratingNicheIdeas ? "Generating..." : "Get Ideas Based on This"}
                    </Button>
                    <Button
                      type="button"
                      onClick={handleCustomIdeaSubmit}
                      disabled={isRegeneratingEmail || !customNicheIdea.trim()}
                      variant="outline"
                      size="sm"
                      data-testid="button-use-custom-idea"
                    >
                      <RefreshCw className="h-4 w-4 mr-1" />
                      {isRegeneratingEmail ? "Generating..." : "Use Directly"}
                    </Button>
                  </div>
                </div>
                
                {/* Existing Content Ideas Selection */}
                {(() => {
                  const contentTemplate = contentTemplates.find(
                    (t: any) => t.nicho.toLowerCase() === brand.nicho.toLowerCase()
                  );
                  
                  // Extract existing ideas from template
                  const existingIdeas: string[] = [];
                  
                  if (contentTemplate?.idea) {
                    const ideaLines = contentTemplate.idea.split('\n').filter(line => line.trim());
                    
                    ideaLines.forEach((line) => {
                      const cleanLine = line.replace(/^•\s*/, '').trim();
                      
                      // Check if this line contains a formatted idea
                      const fullFormatMatch = cleanLine.match(/In order to achieve good reach with your product, I propose the following content idea:\s*["""']\s*([^"""']+?)\s*["""']/i);
                      if (fullFormatMatch) {
                        const extractedIdea = fullFormatMatch[1].trim();
                        if (extractedIdea && !existingIdeas.includes(extractedIdea)) {
                          existingIdeas.push(extractedIdea);
                        }
                      } else {
                        // If not formatted, check if it's a simple idea
                        if (cleanLine && 
                            cleanLine.length < 150 && 
                            cleanLine.length > 3 && // Don't take single letters or too short text
                            !cleanLine.includes('In order to achieve') && 
                            !cleanLine.includes('I want to show you') &&
                            !cleanLine.includes('according to the link') &&
                            !existingIdeas.includes(cleanLine)) {
                          existingIdeas.push(cleanLine);
                        }
                      }
                    });
                    
                    // Also check originalIdea and proposedIdea fields if they exist
                    if (contentTemplate.originalIdea && !existingIdeas.includes(contentTemplate.originalIdea)) {
                      existingIdeas.push(contentTemplate.originalIdea);
                    }
                    if (contentTemplate.proposedIdea && !existingIdeas.includes(contentTemplate.proposedIdea)) {
                      existingIdeas.push(contentTemplate.proposedIdea);
                    }
                  }
                  
                  return existingIdeas.length > 0 && (
                    <div className="space-y-3 bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                      <Label className="text-sm font-medium">Pre-existing Content Ideas</Label>
                      <p className="text-xs text-muted-foreground">Select from ideas already saved for this niche</p>
                      <Select 
                        value={selectedNicheIdea} 
                        onValueChange={(value) => {
                          setSelectedNicheIdea(value === "none" ? "" : value);
                          if (value !== "none") {
                            setCustomNicheIdea(value);
                          }
                        }}
                      >
                        <SelectTrigger data-testid="select-existing-idea">
                          <SelectValue placeholder="Choose a pre-existing idea..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No pre-existing idea</SelectItem>
                          {existingIdeas.map((idea: string, index: number) => (
                            <SelectItem key={index} value={idea}>
                              {idea.length > 60 ? `${idea.substring(0, 60)}...` : idea}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {selectedNicheIdea && (
                        <p className="text-xs text-muted-foreground bg-white dark:bg-gray-800 p-2 rounded border">
                          Selected idea: {selectedNicheIdea}
                        </p>
                      )}
                    </div>
                  );
                })()}

                {/* Video Link Selection */}
                {(() => {
                  const videoTemplate = contentTemplates.find(
                    (t: any) => t.nicho.toLowerCase() === brand.nicho.toLowerCase()
                  );
                  return videoTemplate?.videoLinks && videoTemplate.videoLinks.length > 0 && (
                    <div className="space-y-3 bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                      <Label className="text-sm font-medium">Reference Video Link</Label>
                      <p className="text-xs text-muted-foreground">Select a video link to reference in your content idea</p>
                      <Select value={selectedVideoLink} onValueChange={setSelectedVideoLink}>
                        <SelectTrigger data-testid="select-video-link">
                          <SelectValue placeholder="Choose a video link..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No video link</SelectItem>
                          {videoTemplate.videoLinks?.map((link: string, index: number) => (
                            <SelectItem key={index} value={link}>
                              {link.length > 50 ? `${link.substring(0, 50)}...` : link}
                            </SelectItem>
                          )) || []}
                        </SelectContent>
                      </Select>
                      {selectedVideoLink && selectedVideoLink !== "none" && (
                        <p className="text-xs text-muted-foreground">
                          Selected: <a href={selectedVideoLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                            {selectedVideoLink}
                          </a>
                        </p>
                      )}
                    </div>
                  );
                })()}
                
                {/* AI Generated Ideas */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <Label>AI Suggestions</Label>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => generateNicheIdeas()}
                      disabled={isGeneratingNicheIdeas}
                      className="text-xs"
                      data-testid="button-generate-niche-ideas"
                    >
                      <Sparkles className="h-3 w-3 mr-1" />
                      {isGeneratingNicheIdeas ? "Generating..." : "Get Random Ideas"}
                    </Button>
                  </div>
                  
                  {nicheIdeas.length > 0 && (
                    <div className="space-y-3">
                      {nicheIdeas.map((idea, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <button
                            type="button"
                            className={`flex-1 text-left p-3 rounded border transition-colors ${
                              selectedNicheIdea === idea 
                                ? "bg-primary/10 border-primary" 
                                : "bg-muted/50 hover:bg-muted border-border"
                            }`}
                            onClick={() => {
                              setSelectedNicheIdea(idea);
                              regenerateEmailWithIdea(idea);
                            }}
                            disabled={isRegeneratingEmail}
                            data-testid={`niche-idea-${index}`}
                          >
                            <div className="text-sm font-medium text-foreground">{`AI Idea ${index + 1}`}</div>
                            <div className="text-xs text-muted-foreground mt-1">{idea}</div>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
            
            <div>
              <Label>Variables</Label>
              <div className="space-y-3 bg-muted/50 p-4 rounded-lg">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{"{{contacto}}"}</span>
                  <span className="text-foreground">{brand.contacto || "team"}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{"{{marca}}"}</span>
                  <span className="text-foreground">{brand.marca}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{"{{nicho}}"}</span>
                  <Badge variant="secondary">{brand.nicho}</Badge>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{"{{campaña}}"}</span>
                  <span className="text-foreground">{brand.campania || "General"}</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Email Preview */}
          <div>
            <Label>Email Preview</Label>
            <div className="bg-muted/50 p-6 rounded-lg h-96 overflow-auto">
              <div 
                className="space-y-4 text-sm text-foreground"
                dangerouslySetInnerHTML={{ __html: generatePreview() }}
                data-testid="email-preview"
              />
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between pt-6 border-t border-border">
          <div></div>
          <div className="flex items-center space-x-4">
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
              data-testid="button-cancel-email"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSendEmail}
              disabled={sendEmailMutation.isPending}
              data-testid="button-send-email"
            >
              {sendEmailMutation.isPending ? "Sending..." : "Send Email"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
